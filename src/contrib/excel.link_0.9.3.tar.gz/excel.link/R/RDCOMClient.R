#' Functions from RDCOMClient package
#' 
#' For details about these functions see help for RDCOMClient package by 
#' Duncan Temple Lang \email{duncan@@wald.ucdavis.edu}: 
#' \url{http://www.omegahat.org/RDCOMClient}, \url{http://www.omegahat.org}.
#' 
#' @author Duncan Temple Lang \email{duncan@@wald.ucdavis.edu}
#' 
#' @name RDCOMClient
#' 
#' @param msg See RDCOMClient documentation.
#' @param status See RDCOMClient documentation.
#' @param class See RDCOMClient documentation.
#' @param ref See RDCOMClient documentation.
#' @param className See RDCOMClient documentation.
#' @param name See RDCOMClient documentation.
#' @param ... See RDCOMClient documentation.
#' @param existing See RDCOMClient documentation.
#' @param guid See RDCOMClient documentation.
#' @param force See RDCOMClient documentation.
#' @param silent See RDCOMClient documentation.
#' @param appName See RDCOMClient documentation.
#' @param x See RDCOMClient documentation.
#' @param i See RDCOMClient documentation.
#' @param j See RDCOMClient documentation.
#' @param obj See RDCOMClient documentation.
#' @param .dispatch See RDCOMClient documentation.
#' @param .return See RDCOMClient documentation.
#' @param .ids See RDCOMClient documentation.
#' @param .suppliedArgs See RDCOMClient documentation.
#' @param X See RDCOMClient documentation.
#' @param FUN See RDCOMClient documentation.
#' @param simplify See RDCOMClient documentation.
#' @param USE.NAMES See RDCOMClient documentation.
#' @param drop See RDCOMClient documentation.
#' @param exact See RDCOMClient documentation.
#' @param object See RDCOMClient documentation.
#' @param id See RDCOMClient documentation.
#' @param value See RDCOMClient documentation.
#' @param var See RDCOMClient documentation.
#' @param quote See RDCOMClient documentation.
#' @param type See RDCOMClient documentation.
#' @param env See RDCOMClient documentation.
#' @param namesOnly See RDCOMClient documentation.
NULL


