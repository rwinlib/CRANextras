STATISTICS *summary( OUTPUT *,double *);
STATISTICS *summary_tau_sigma_scale( OUTPUT *,double *);

